using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : Danger
{
    [Header("Enemy generic variables")]
    [SerializeField] protected float moveSpeed;
    [SerializeField] protected float idleTime;
    protected Animator anim;
    protected Rigidbody2D rb;
    [SerializeField] protected int facingDirection = 1;
    protected float idleTimeCounter;
    protected bool isMoving;
    [HideInInspector] public bool invincible;
    protected bool canMove = true;
    protected bool isAggresive;

    [Header("Collision detection")]
    [SerializeField] protected LayerMask whatIsGround;
    [SerializeField] protected float groundCheckDistance;
    [SerializeField] protected float wallCheckDistance;
    [SerializeField] protected Transform groundCheck;
    [SerializeField] protected Transform wallCheck;
    protected bool isWallDetected;
    protected bool isGroundDetected;

    [Header("Player detection")]
    [SerializeField] private LayerMask whatToIgnore;
    protected RaycastHit2D playerDetection;
    protected bool playerDetected = false;
    protected Transform player;
    
    protected virtual void Start()
    {
        player = PlayerManager.instance.currentPlayer.transform;
        
        facingDirection = -1;
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();

        if(groundCheck == null) groundCheck = transform;
        if(wallCheck == null) wallCheck = transform;
    }

    public virtual void Damage()
    {
        canMove = false;
        if(!invincible) anim.SetTrigger("gotHit");
    }

    public void DestroyMe()
    {
        Destroy(gameObject);
    }

    protected override void OnTriggerEnter2D(Collider2D triggeringObject)
    {
        if(triggeringObject.GetComponent<Player>() != null)
        {
            Player player = triggeringObject.GetComponent<Player>();

            player.Knockback(transform);

            rb.velocity = new Vector2(0, 0);
            Flip();
        }
    }

    protected virtual void CollisionCheck()
    {
        isGroundDetected = Physics2D.Raycast(groundCheck.position, Vector2.down, groundCheckDistance, whatIsGround);
        isWallDetected = Physics2D.Raycast(wallCheck.position, Vector2.right * facingDirection, wallCheckDistance, whatIsGround);
    }

    protected virtual void PlayerDetection()
    {
        playerDetection = Physics2D.Raycast(wallCheck.position, Vector2.right * facingDirection, 100, ~whatToIgnore);
        playerDetected = playerDetection.collider.GetComponent<Player>() != null;
    }

    protected virtual void OnDrawGizmos()
    {
        if(groundCheck != null) Gizmos.DrawLine(groundCheck.position, new Vector2(groundCheck.position.x, groundCheck.position.y - groundCheckDistance));
        if(wallCheck != null)
        {
            Gizmos.DrawLine(wallCheck.position, new Vector2(wallCheck.position.x + wallCheckDistance * facingDirection, wallCheck.position.y));
            Gizmos.DrawLine(wallCheck.position, new Vector2(wallCheck.position.x + playerDetection.distance * facingDirection, wallCheck.position.y));
        }
    }

    protected virtual void Flip()
    {
        facingDirection = facingDirection * -1;
        transform.Rotate(0, 180, 0);
    }

    protected virtual void WalkAround()
    {
        idleTimeCounter -= Time.deltaTime;

        if(idleTimeCounter <= 0 && canMove)
        {
            rb.velocity = new Vector2(moveSpeed * facingDirection, rb.velocity.y);
            isMoving = true;
        }
        else
        {
            isMoving = false;
            rb.velocity = new Vector2(0, rb.velocity.y);
        }

        if(isWallDetected)
        {
            idleTimeCounter = idleTime;
            Flip();
        }
    }
}
