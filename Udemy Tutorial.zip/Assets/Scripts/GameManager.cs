using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;
    public int difficulty;

    [Header("Timer info")]
    public float timer;
    public bool startTimer;

    [Header("Level info")]
    public int levelNumber;

    private void Awake()
    {
        DontDestroyOnLoad(this.gameObject);
        
        if(instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(this.gameObject);
        }
    }

    private void Start()
    {
        if(difficulty == 0) difficulty = PlayerPrefs.GetInt("GameDifficulty");
    }

    private void Update()
    {
        if(startTimer) timer += Time.deltaTime;
    }

    public void SetDifficulty()
    {
        PlayerPrefs.SetInt("GameDifficulty", difficulty);
    }

    public void SaveBestTime()
    {
        float bestTime = PlayerPrefs.GetFloat("Level"+ levelNumber + "Best time");
        if(timer < bestTime) PlayerPrefs.SetFloat("Level"+ levelNumber + "Best time", timer);

        Debug.Log("Time: " + timer);
        startTimer = false;
        timer = 0;
    }

    public void SaveCollectedFruits()
    {
        int totalFruits = PlayerPrefs.GetInt("TotalFruitsCollected");
        int newTotalFruits = totalFruits + PlayerManager.instance.fruits;

        PlayerPrefs.SetInt("TotalFruitsCollected", newTotalFruits);
        PlayerPrefs.SetInt("Level" + levelNumber + "FruitsCollected", PlayerManager.instance.fruits);

        PlayerManager.instance.fruits = 0;
    }
}
