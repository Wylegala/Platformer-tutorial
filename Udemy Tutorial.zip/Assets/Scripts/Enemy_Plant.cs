using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Plant : Enemy
{
    [Header("Plant specific variables")]
    [SerializeField] private GameObject bulletPrefab;
    [SerializeField] private Transform bulletPosition;
    [SerializeField] private float bulletSpeed;
    [SerializeField] private bool facingRight;

    protected override void Start()
    {
        base.Start();
        if(facingRight) Flip();
    }

    private void Update()
    {
        PlayerDetection();
        idleTimeCounter -= Time.deltaTime;

        if(idleTimeCounter < 0 && playerDetected)
        {
            idleTimeCounter = idleTime;
            anim.SetTrigger("attack");
        }
    }

    private void AttackEvent()
    {
        GameObject newBullet = Instantiate(bulletPrefab, bulletPosition.transform.position, bulletPosition.transform.rotation);
        newBullet.GetComponent<Bullet>().SetupSpeed(bulletSpeed * facingDirection, 0);
    }
}
