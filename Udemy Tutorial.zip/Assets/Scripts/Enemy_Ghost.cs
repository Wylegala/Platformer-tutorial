using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Ghost : Enemy
{
    [Header("Ghost specific variables")]
    [SerializeField] private float[] xOffset;
    [SerializeField] private float activeTime;
    private float activeTimeCounter = 4;

    private SpriteRenderer sr;

    protected override void Start()
    {
        base.Start();
        isAggresive = true;
        invincible = true;
        facingDirection = -1;

        sr = GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        if(player == null)
        {
            anim.SetTrigger("disappear");
            return;
        }

        idleTimeCounter -= Time.deltaTime;
        activeTimeCounter -= Time.deltaTime;

        if(activeTimeCounter > 0)
        {
            transform.position = Vector2.MoveTowards(transform.position, player.transform.position, moveSpeed * Time.deltaTime);
        }

        if(activeTimeCounter < 0 && idleTimeCounter < 0 && isAggresive)
        {
            anim.SetTrigger("disappear");
            isAggresive = false;
            idleTimeCounter = idleTime;
        }

        if(activeTimeCounter < 0 && idleTimeCounter < 0 && !isAggresive)
        {
            ChoosePosition();
            anim.SetTrigger("appear");
            isAggresive = true;
            activeTimeCounter = activeTime;
        }

        FlipController();
    }

    private void ChoosePosition()
    {
        float _xOffset = xOffset[Random.Range(0, xOffset.Length)];
        float _yOffset = Random.Range(-7, 7);
        transform.position = new Vector2(player.transform.position.x + _xOffset, player.transform.position.y + _yOffset);
    }

    public void Disappear() => sr.enabled = false;
    public void Appear() => sr.enabled = true;

    private void FlipController()
    {
        if(player == null) return;

        if(player.transform.position.x > transform.position.x && facingDirection == -1) Flip();
        else if(player.transform.position.x < transform.position.x && facingDirection == 1) Flip();
    }

    protected override void OnTriggerEnter2D(Collider2D triggeringObject)
    {
        if(isAggresive)
        {
            if(triggeringObject.GetComponent<Player>() != null)
            {
                Player player = triggeringObject.GetComponent<Player>();

                player.Knockback(transform);
            }
        }
    }

}
