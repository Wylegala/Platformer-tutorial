using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartPoint : MonoBehaviour
{
    [SerializeField] private Transform respPoint;

    private void Awake()
    {
        PlayerManager.instance.respawnPoint = respPoint;
        PlayerManager.instance.PlayerRespawn();
    }

    private void OnTriggerExit2D(Collider2D triggeringObject)
    {
        if(triggeringObject.GetComponent<Player>() != null)
        {
            if(!GameManager.instance.startTimer) GameManager.instance.startTimer = true;

            if(triggeringObject.transform.position.x > transform.position.x) GetComponent<Animator>().SetTrigger("touched");
        }
    }
}
