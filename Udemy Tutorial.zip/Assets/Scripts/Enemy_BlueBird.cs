using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_BlueBird : Enemy
{
    [Header("Collision detection")]
    [SerializeField] protected float ceilingDistance;
    private RaycastHit2D groundAboveDetected;

    [Header("Fly info")]
    [SerializeField] protected float flyUpForce;
    [SerializeField] protected float flyDownForce;
    protected float flyForce;
    private bool canFly = true;

    protected override void Start()
    {
        base.Start();
        flyForce = flyUpForce;
    }

    private void Update()
    {
        CollisionCheck();

        if(groundAboveDetected) flyForce = flyDownForce;
        else if(isGroundDetected) flyForce = flyUpForce;

        if(isWallDetected) Flip();
    }

    public override void Damage()
    {
        canFly = false;
        rb.gravityScale = 0;
        rb.velocity = new Vector2(0, 0);
        base.Damage();
    }

    public void FlyUp()
    {
        if(canFly) rb.velocity = new Vector2(moveSpeed * facingDirection, flyForce);
    }

    protected override void CollisionCheck()
    {
        base.CollisionCheck();
        groundAboveDetected = Physics2D.Raycast(transform.position, Vector2.up, ceilingDistance, whatIsGround);
    }

    protected override void OnDrawGizmos()
    {
        base.OnDrawGizmos();
        Gizmos.DrawLine(transform.position, new Vector2(transform.position.x, transform.position.y + ceilingDistance));
    }
}
