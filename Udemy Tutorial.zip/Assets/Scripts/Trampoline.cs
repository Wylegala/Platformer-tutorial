using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trampoline : MonoBehaviour
{
    [SerializeField] private float pushForce = 20;
    private bool canbeUsed = true;

    private void OnTriggerEnter2D(Collider2D triggeringObject)
    {
        if(triggeringObject.GetComponent<Player>() != null && canbeUsed)
        {
            canbeUsed = false;
            GetComponent<Animator>().SetTrigger("activate");
            triggeringObject.GetComponent<Player>().TrampolinePush(pushForce);
        }
    }

    private void ActivateTrampoline() => canbeUsed = true;
}
