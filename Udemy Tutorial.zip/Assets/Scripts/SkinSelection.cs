using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class SkinSelection : MonoBehaviour
{
    [SerializeField] private Animator anim;
    [SerializeField] private GameObject buyButton;
    [SerializeField] private GameObject selectButton;
    [SerializeField] private int skinID;
    [SerializeField] private bool[] skinPurchased;
    [SerializeField] private int[] skinPrice;

    [SerializeField] private TextMeshProUGUI bankText;

    private void Start()
    {
        skinPurchased[0] = true;

        bankText.text = PlayerPrefs.GetInt("TotalFruitsCollected").ToString();
    }

    public void NextSkin()
    {
        skinID++;
        if(skinID > 3) skinID = 0;

        CheckSkinInfo();
    }

    public void PreviousSkin()
    {
        skinID--;
        if(skinID < 0) skinID = 3;

        CheckSkinInfo();
    }

    public void BuySkin()
    {
        skinPurchased[skinID] = true;

        CheckSkinInfo();
    }

    public void SelectSkin()
    {
        PlayerManager.instance.chosenSkinID = skinID;
    }

    public void CheckSkinInfo()
    {
        selectButton.SetActive(skinPurchased[skinID]);
        buyButton.SetActive(!skinPurchased[skinID]);

        if(!skinPurchased[skinID]) buyButton.GetComponentInChildren<TextMeshProUGUI>().text = "Price: " + skinPrice[skinID];

        anim.SetInteger("skinID", skinID);
    }
}
