using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Timer_UI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI timerText;
    [SerializeField] private TextMeshProUGUI currentFruitAmount;

    void Update()
    {
        timerText.text = "Time: " + GameManager.instance.timer.ToString("00") + "s";
        currentFruitAmount.text = PlayerManager.instance.fruits.ToString();
    }
}
