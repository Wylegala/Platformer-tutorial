using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerManager : MonoBehaviour
{
    public static PlayerManager instance;

    public Transform respawnPoint;
    public GameObject currentPlayer;
    public int chosenSkinID;
    public int fruits;

    [SerializeField] private GameObject playerPrefab;

    private void Awake()
    {
        DontDestroyOnLoad(this.gameObject);
        
        if(instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(this.gameObject);
        }
    }

    public void PlayerRespawn()
    {
        if(currentPlayer == null) currentPlayer = Instantiate(playerPrefab, respawnPoint.position, transform.rotation);
    }
}
