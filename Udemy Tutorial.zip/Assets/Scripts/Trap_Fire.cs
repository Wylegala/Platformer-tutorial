using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trap_Fire : Danger
{
    public bool isActive;
    private Animator anim;

    private void Start()
    {
        anim = GetComponent<Animator>();
        InvokeRepeating("FireSwitch", 3, 3);
    }

    private void Update()
    {
        anim.SetBool("isActive", isActive);
    }

    protected override void OnTriggerEnter2D(Collider2D triggeringObject)
    {
        if(isActive) base.OnTriggerEnter2D(triggeringObject);
    }

    private void FireSwitch()
    {
        isActive = !isActive;
    }
}
