using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    [Header("Player generic variables")]
    [SerializeField] private bool canBeHit = true;
    private Rigidbody2D rb;
    private Animator anim;
    
    [Header("Movement info")]
    [SerializeField] private float moveSpeed = 7.5f;
    [SerializeField] private float jumpForce = 15f;
    private float movingInput;
    [SerializeField] protected bool canMove;
    private bool isFacingRight = true;
    private int facingDirection = 1;

    [Header("Jump info")]
    [SerializeField] private float bufferJumpTime;
    [SerializeField] private float coyoteJumpTime;
    private float coyoteJumpCounter;
    private float bufferJumpCounter;
    private bool canCoyoteJump;
    private bool canDoubleJump;
    private bool canWallSlide;
    private bool isWallSliding;
    

    [Header("Collision info")]
    [SerializeField] private LayerMask whatIsGround;
    [SerializeField] private LayerMask whatIsWall;
    [SerializeField] private float groundCheckDistance;
    [SerializeField] private float wallCheckDistance;
    [SerializeField] protected Transform wallCheck;
    [SerializeField] protected Transform groundCheck;
    [SerializeField] protected bool isGrounded;
    [SerializeField] protected bool isWallDetected;

    [Header("Enemy detection info")]
    [SerializeField] private Transform enemyCheck;
    [SerializeField] private float enemyCheckBoxX;
    [SerializeField] private float enemyCheckBoxY;

    [Header("Knockback Info")]
    [SerializeField] private Vector2 knockbackDirection;
    [SerializeField] private float knockbackTime;
    [SerializeField] private float knockbackProtectionTime;
    private bool isKnocked;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        bufferJumpCounter -= Time.deltaTime;
        coyoteJumpCounter -= Time.deltaTime;

        AnimationController();

        if(isKnocked) return;

        FlipController();

        CheckCollision();

        InputCheck();

        CheckForEnemy();

        if(isGrounded)
        {
            canDoubleJump = true;
            canMove = true;

            if(bufferJumpCounter > 0)
            {
                bufferJumpCounter = -1;
                Jump();
            }

            canCoyoteJump = true;
        }
        else
        {
            if(canCoyoteJump)
            {
                coyoteJumpCounter = coyoteJumpTime;
                canCoyoteJump = false;
            }
        }

        if(canWallSlide)
        {
            isWallSliding = true;
            rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y * 0.1f);
        }

        Move();
    }

    private void AnimationController()
    {
        bool isMoving = rb.velocity.x != 0;
        anim.SetBool("isMoving", isMoving);
        anim.SetBool("isGrounded", isGrounded);
        anim.SetBool("isWallSliding", isWallSliding);
        anim.SetBool("isWallDetected", isWallDetected);
        anim.SetBool("isKnocked", isKnocked);
        anim.SetFloat("yVelocity", rb.velocity.y);
    }

    private void InputCheck()
    {
        movingInput = Input.GetAxisRaw("Horizontal");
        
        if(Input.GetAxis("Vertical") < 0) canWallSlide = false;
        if(Input.GetKeyDown(KeyCode.Space)) JumpButton();
    }

    private void CheckForEnemy()
    {
        Collider2D[] hitColliders = Physics2D.OverlapBoxAll(enemyCheck.position, new Vector2(enemyCheckBoxX, enemyCheckBoxY), 0);
        
        foreach (var enemy in hitColliders)
        {
            if(enemy.GetComponent<Enemy>() != null)
            {
                Enemy newEnemy = enemy.GetComponent<Enemy>();

                if(newEnemy.invincible) return;

                if(rb.velocity.y < 0)
                {
                    newEnemy.Damage();
                    Jump();
                }
            }
        }
    }

    private void Move()
    {
        if(canMove) rb.velocity = new Vector2(moveSpeed * movingInput, rb.velocity.y);
    }

    private void JumpButton()
    {
        if(!isGrounded) bufferJumpCounter = bufferJumpTime;
        
        if(isGrounded || coyoteJumpCounter > 0)
        {
            Jump();
        }
        else if(canDoubleJump)
        {
            canDoubleJump = false;
            Jump();
        }
        else if(isWallSliding)
        {
            WallJump();
        }

        canWallSlide = false;
    }

    private void Jump()
    {
        rb.velocity = new Vector2(rb.velocity.x, jumpForce);
    }

    public void TrampolinePush(float pushForce)
    {
        rb.velocity = new Vector2(rb.velocity.x, pushForce);
    }

    private void WallJump()
    {
        canMove = false;
        rb.velocity = new Vector2(5 * -facingDirection, jumpForce);
    }

    public void Knockback(Transform damageTransform)
    {
        if(!canBeHit) return;
        
        isKnocked = true;
        canBeHit = false;

        #region Define horizontal knockback direction
        int hDirection = 0;
        if(transform.position.x > damageTransform.position.x) hDirection = 1;
        else if(transform.position.x < damageTransform.position.x) hDirection = -1;

        rb.velocity = new Vector2(knockbackDirection.x * hDirection, knockbackDirection.y);
        #endregion

        Invoke("CancelKnockback", knockbackTime);
        Invoke("AllowKnockback", knockbackProtectionTime);

        if(GameManager.instance.difficulty > 1)
        {
            PlayerManager.instance.fruits--;
            Invoke("CheckIfDead", knockbackTime);
        }
    }

    private void CancelKnockback()
    {
        isKnocked = false;
    }

    private void AllowKnockback()
    {
        canBeHit = true;
    }

    private void CheckIfDead()
    {
        if(PlayerManager.instance.fruits < 0)
        {
           Destroy(gameObject);
        }
    }

    private void Flip()
    {
        transform.Rotate(0, 180, 0);
        isFacingRight = !isFacingRight;
        facingDirection = facingDirection * -1;
    }

    private void FlipController()
    {
        if(isFacingRight && rb.velocity.x < -.1f) Flip();
        else if(!isFacingRight && rb.velocity.x > .1f) Flip();
    }

    private void CheckCollision()
    {
        isGrounded = Physics2D.Raycast(groundCheck.position, Vector2.down, groundCheckDistance, whatIsGround);
        isWallDetected = Physics2D.Raycast(wallCheck.position, Vector2.right * facingDirection, wallCheckDistance, whatIsWall);
    
        if(isWallDetected && rb.velocity.y < 0)
        {
            canWallSlide = true;
            canDoubleJump = false;
        }
        
        if(!isWallDetected)
        {
            canWallSlide = false;
            isWallSliding = false;
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawLine(groundCheck.position, new Vector3(groundCheck.position.x, groundCheck.position.y - groundCheckDistance));
        Gizmos.DrawLine(wallCheck.position, new Vector3(wallCheck.position.x + wallCheckDistance * facingDirection, wallCheck.position.y));
        Gizmos.DrawWireCube(enemyCheck.position, new Vector2(enemyCheckBoxX, enemyCheckBoxY));
    }
}
