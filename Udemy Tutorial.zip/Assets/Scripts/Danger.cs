using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Danger : MonoBehaviour
{
    protected virtual void OnTriggerEnter2D(Collider2D triggeringObject)
    {
        if(triggeringObject.tag == "Player")
        {
            Player player = triggeringObject.GetComponent<Player>();
            
            player.Knockback(transform);
        }
    }
}
