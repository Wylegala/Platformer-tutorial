using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class LevelManager : MonoBehaviour
{
    [SerializeField] private GameObject prefabButton;
    [SerializeField] private Transform parentButton;

    [SerializeField] private bool[] levelUnlocked;
    
    private void Start()
    {
        for(int i = 1; i < SceneManager.sceneCountInBuildSettings; i++)
        {
            if(!levelUnlocked[i]) return;

            string sceneName = "Level " + i;

            GameObject newButton = Instantiate(prefabButton, parentButton);
            newButton.GetComponent<Button>().onClick.AddListener(() => LoadLevel(sceneName));
            newButton.GetComponentInChildren<TextMeshProUGUI>().text = sceneName;
        }
    }

    public void LoadLevel(string sceneToLoad)
    {
        GameManager.instance.SetDifficulty();
        SceneManager.LoadScene(sceneToLoad);
    }
}