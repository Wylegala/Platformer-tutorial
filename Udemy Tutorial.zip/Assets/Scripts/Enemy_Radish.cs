using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Radish : Enemy
{
    [Header("Radish specific variables")]
    [SerializeField] private float aggresiveTime;
    [SerializeField] private float flyingSpeed;
    private float aggresiveTimeCounter;

    [Header("Collision detection")]
    [SerializeField] protected float ceilingDistance;
    [SerializeField] protected float groundDistance;
    private RaycastHit2D groundAboveDetected;
    private RaycastHit2D groundBelowDetected;

    protected override void Start()
    {
        base.Start();
    }

    void Update()
    {
        aggresiveTimeCounter -= Time.deltaTime;
        if(aggresiveTimeCounter < 0)
        {
            rb.gravityScale = 1;
            isAggresive = false;
        }

        if(!isAggresive && !groundAboveDetected)
        {
            Fly();
        }
        else if(groundBelowDetected)
        {
            WalkAround();
        }

        CollisionCheck();
        AnimationController();
    }

    public override void Damage()
    {
        if(!isAggresive)
        {
            aggresiveTimeCounter = aggresiveTime;
            rb.gravityScale = 12;
            isAggresive = true;
        }
        else base.Damage();
    }

    private void AnimationController()
    {
        anim.SetFloat("xVelocity", rb.velocity.x);
        anim.SetBool("isAggresive", isAggresive);
    }

    private void Fly()
    {
        if(groundBelowDetected && !groundAboveDetected)
        {
            rb.velocity = new Vector2(0, flyingSpeed);
        }
    }

    protected override void CollisionCheck()
    {
        base.CollisionCheck();
        groundAboveDetected = Physics2D.Raycast(transform.position, Vector2.up, ceilingDistance, whatIsGround);
        groundBelowDetected = Physics2D.Raycast(transform.position, Vector2.down, groundDistance, whatIsGround);
    }

    protected override void OnDrawGizmos()
    {
        base.OnDrawGizmos();
        Gizmos.DrawLine(transform.position, new Vector2(transform.position.x, transform.position.y + ceilingDistance));
        Gizmos.DrawLine(transform.position, new Vector2(transform.position.x, transform.position.y - groundDistance));
    }
}
