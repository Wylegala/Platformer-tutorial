using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trap_Saw : Danger
{
    private Animator anim;
    
    [SerializeField] private float speed;
    [SerializeField] private Transform[] movePoint;
    [SerializeField] private float cooldown;

    private int movePointIndex;
    private float cooldownTimer;

    private void Start()
    {
        anim = GetComponent<Animator>();
        transform.position = movePoint[0].position;
        Flip();
    }

    private void Update()
    {
        cooldownTimer -= Time.deltaTime;

        bool isActive = cooldownTimer < 0;
        anim.SetBool("isActive", isActive);

        if(isActive) transform.position = Vector3.MoveTowards(transform.position, movePoint[movePointIndex].position, speed * Time.deltaTime);

        if(Vector2.Distance(transform.position, movePoint[movePointIndex].position) < 0.25f)
        {
            Flip();
            cooldownTimer = cooldown;

            movePointIndex++;
            if(movePointIndex >= movePoint.Length) movePointIndex = 0;
        }
    }

    private void Flip()
    {
        transform.localScale = new Vector3(1, transform.localScale.y * -1);
    }
}
