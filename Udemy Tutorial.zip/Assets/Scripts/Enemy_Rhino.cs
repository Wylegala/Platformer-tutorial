using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Rhino : Enemy
{
    [Header("Rhino specific variables")]
    [SerializeField] private float runSpeed;

    [Header("Shock info")]
    [SerializeField] private float shockTime;
    private float shockTimeCounter;

    protected override void Start()
    {
        base.Start();
        invincible = true;
    }

    private void Update()
    {
        PlayerDetection();
        
        if(playerDetected) isAggresive = true;

        if(!isAggresive)
        {   
            WalkAround();
        }
        else
        {
            rb.velocity = new Vector2(runSpeed * facingDirection, rb.velocity.y);

            if(isWallDetected && invincible)
            {
                invincible = false;
                shockTimeCounter = shockTime;
            }

            if(shockTimeCounter <= 0 && !invincible)
            {
                invincible = true;
                Flip();
                isAggresive = false;
            }

            shockTimeCounter -= Time.deltaTime;
        }

        CollisionCheck();
        AnimationController();
    }

    protected override void OnTriggerEnter2D(Collider2D triggeringObject)
    {
        base.OnTriggerEnter2D(triggeringObject);

        if(invincible & !isAggresive) return;

        invincible = true;
        isAggresive = false;
    }

    private void AnimationController()
    {
        anim.SetFloat("xVelocity", rb.velocity.x);
        anim.SetBool("invincible", invincible);
    }
}
