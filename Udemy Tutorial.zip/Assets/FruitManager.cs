using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FruitManager : MonoBehaviour
{
    [SerializeField] private Transform[] fruitPositions;

    private void Start()
    {
        fruitPositions = GetComponentsInChildren<Transform>();

        int levelNumber = GameManager.instance.levelNumber;
        PlayerPrefs.SetInt("Level" + levelNumber + "TotalFruits", fruitPositions.Length - 1);

        Debug.Log("Total fruits on the level: " + PlayerPrefs.GetInt("Level" + levelNumber + "TotalFruits"));
    }
}
